﻿using System;

namespace ClassLibrary1
{
    public class Class1
    {
        public static double MinAVG(string[] Marks)
        {
            double res = 0;
            int[] array = new int[Marks.Length];
            double sum = 0;
            for (int i = 0; i < Marks.Length; i++)
            {
                int num;
                bool isNum = int.TryParse(Marks[i], out num);
                if (isNum)
                {
                    array[i] = Convert.ToInt32(Marks[i]);
                    Console.WriteLine(array[i]);
                    sum = sum + array[i];
                }
                else
                {
                    res = 0;
                }
                   
                
                /*array[i] = Convert.ToInt32(Marks[i]);
                sum += array[i];*/
                
            }
            if(Marks.Length == 0)
            {
                res = 0;
            }
            else
            {
                res = sum / Marks.Length;
            }
            return res;
        }
    }
}
